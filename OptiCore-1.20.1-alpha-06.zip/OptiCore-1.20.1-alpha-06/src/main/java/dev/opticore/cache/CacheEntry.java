package dev.opticore.cache;

/**
 * A disposable, derived piece of rendering data (for example a baked vertex
 * buffer for one chunk section). Implementations MUST NOT hold references to
 * live world state, entities, or gameplay objects: an entry must be safe to
 * drop at any moment and rebuildable from the world.
 */
public interface CacheEntry {
    /** Approximate retained size in bytes. Must stay constant for the entry's lifetime. */
    long sizeBytes();

    /**
     * Frees any resources held by the entry. Called exactly once, by the cache,
     * after the entry is evicted, invalidated, replaced or rejected. Always
     * called outside the cache lock. Exceptions are caught and counted.
     * Entries wrapping GPU or off-heap resources must be reference-counted by
     * the consumer, because a reader may still hold an entry returned by get().
     */
    default void release() {}
}
