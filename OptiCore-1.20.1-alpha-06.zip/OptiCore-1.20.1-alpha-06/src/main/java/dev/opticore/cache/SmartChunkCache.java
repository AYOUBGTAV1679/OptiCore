package dev.opticore.cache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Predicate;

/**
 * Bounded, thread-safe LRU cache for disposable chunk render data.
 *
 * <p>Engineering decisions:
 * <ul>
 *   <li><b>Bound is in bytes, not entry count</b>, because section buffers vary
 *       widely in size; the limit is changeable at runtime via {@link #setMaxBytes}.</li>
 *   <li><b>One ReentrantLock</b> guards the access-ordered LinkedHashMap. LRU
 *       reads mutate order, so a read/write lock would not help. Critical
 *       sections are O(1) except invalidation scans, which are O(n) on a
 *       bounded n.</li>
 *   <li><b>Release callbacks run outside the lock</b> so slow or throwing
 *       cleanup cannot stall or corrupt the cache.</li>
 *   <li><b>Generation stamps</b> implement invalidation for resource reloads and
 *       render-setting changes in O(1): bumping a generation makes every older
 *       entry stale; stale entries are dropped lazily on access or by
 *       {@link #purgeStale()}.</li>
 *   <li>Chunk changes use explicit {@link #invalidateChunk}.</li>
 * </ul>
 * This class knows nothing about Minecraft and stores nothing about simulation.
 */
public final class SmartChunkCache<V extends CacheEntry> {

    private record Slot<V>(V value, long bytes, long resourceGen, long settingsGen) {}

    private final ReentrantLock lock = new ReentrantLock();
    private final LinkedHashMap<RenderCacheKey, Slot<V>> map = new LinkedHashMap<>(64, 0.75f, true);

    private long maxBytes;
    private long currentBytes;
    private long resourceGen;
    private long settingsGen;

    private final AtomicLong hits = new AtomicLong();
    private final AtomicLong misses = new AtomicLong();
    private final AtomicLong evictions = new AtomicLong();
    private final AtomicLong invalidations = new AtomicLong();
    private final AtomicLong rejected = new AtomicLong();
    private final AtomicLong releaseFailures = new AtomicLong();

    public SmartChunkCache(long maxBytes) {
        if (maxBytes < 0) throw new IllegalArgumentException("maxBytes < 0");
        this.maxBytes = maxBytes;
    }

    /** Returns the entry and marks it most-recently-used, or null on miss/stale. */
    public V get(RenderCacheKey key) {
        V stale = null;
        V found = null;
        lock.lock();
        try {
            Slot<V> s = map.get(key);
            if (s != null) {
                if (s.resourceGen != resourceGen || s.settingsGen != settingsGen) {
                    map.remove(key);
                    currentBytes -= s.bytes;
                    invalidations.incrementAndGet();
                    stale = s.value;
                } else {
                    found = s.value;
                }
            }
        } finally {
            lock.unlock();
        }
        if (stale != null) safeRelease(stale);
        if (found != null) hits.incrementAndGet(); else misses.incrementAndGet();
        return found;
    }

    /**
     * Inserts or replaces an entry. Returns false (and releases the value) if it
     * alone exceeds the memory limit.
     */
    public boolean put(RenderCacheKey key, V value) {
        long bytes = Math.max(0L, value.sizeBytes());
        List<V> toRelease = new ArrayList<>(2);
        boolean stored;
        lock.lock();
        try {
            Slot<V> old = map.remove(key);
            if (old != null) {
                currentBytes -= old.bytes;
                if (old.value != value) toRelease.add(old.value);
            }
            if (bytes > maxBytes) {
                rejected.incrementAndGet();
                if (old == null || old.value != value) toRelease.add(value);
                stored = false;
            } else {
                map.put(key, new Slot<>(value, bytes, resourceGen, settingsGen));
                currentBytes += bytes;
                evictToLimit(toRelease);
                stored = true;
            }
        } finally {
            lock.unlock();
        }
        toRelease.forEach(this::safeRelease);
        return stored;
    }

    /** Changes the memory limit; shrinking evicts least-recently-used entries immediately. */
    public void setMaxBytes(long newMax) {
        if (newMax < 0) throw new IllegalArgumentException("maxBytes < 0");
        List<V> toRelease = new ArrayList<>();
        lock.lock();
        try {
            maxBytes = newMax;
            evictToLimit(toRelease);
        } finally {
            lock.unlock();
        }
        toRelease.forEach(this::safeRelease);
    }

    /** Drops every section of one chunk (call when the chunk's blocks/light change or it unloads). */
    public int invalidateChunk(String dimension, int chunkX, int chunkZ) {
        return removeIf(k -> k.inChunk(dimension, chunkX, chunkZ));
    }

    /** Drops everything in a dimension (call on dimension change / disconnect). */
    public int invalidateDimension(String dimension) {
        return removeIf(k -> k.dimension().equals(dimension));
    }

    /** Resource packs reloaded: all existing entries become stale. */
    public void onResourcesReloaded() {
        lock.lock();
        try { resourceGen++; } finally { lock.unlock(); }
    }

    /** A render-affecting setting changed: all existing entries become stale. */
    public void onRenderSettingsChanged() {
        lock.lock();
        try { settingsGen++; } finally { lock.unlock(); }
    }

    /** Eagerly frees entries made stale by generation bumps. Returns how many. */
    public int purgeStale() {
        List<V> toRelease = new ArrayList<>();
        lock.lock();
        try {
            Iterator<Map.Entry<RenderCacheKey, Slot<V>>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Slot<V> s = it.next().getValue();
                if (s.resourceGen != resourceGen || s.settingsGen != settingsGen) {
                    it.remove();
                    currentBytes -= s.bytes;
                    toRelease.add(s.value);
                }
            }
            invalidations.addAndGet(toRelease.size());
        } finally {
            lock.unlock();
        }
        toRelease.forEach(this::safeRelease);
        return toRelease.size();
    }

    /** Releases and removes everything. Safe to call repeatedly (e.g. on world unload / shutdown). */
    public void clear() {
        removeIf(k -> true);
    }

    public long currentBytes() { lock.lock(); try { return currentBytes; } finally { lock.unlock(); } }
    public long maxBytes()     { lock.lock(); try { return maxBytes; } finally { lock.unlock(); } }
    public int size()          { lock.lock(); try { return map.size(); } finally { lock.unlock(); } }

    public Stats stats() {
        return new Stats(hits.get(), misses.get(), evictions.get(), invalidations.get(),
                rejected.get(), releaseFailures.get());
    }

    public record Stats(long hits, long misses, long evictions, long invalidations,
                        long rejected, long releaseFailures) {}

    // ---- internals ----

    private int removeIf(Predicate<RenderCacheKey> filter) {
        List<V> toRelease = new ArrayList<>();
        lock.lock();
        try {
            Iterator<Map.Entry<RenderCacheKey, Slot<V>>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<RenderCacheKey, Slot<V>> e = it.next();
                if (filter.test(e.getKey())) {
                    it.remove();
                    currentBytes -= e.getValue().bytes;
                    toRelease.add(e.getValue().value);
                }
            }
            invalidations.addAndGet(toRelease.size());
        } finally {
            lock.unlock();
        }
        toRelease.forEach(this::safeRelease);
        return toRelease.size();
    }

    /** Caller must hold the lock. */
    private void evictToLimit(List<V> out) {
        Iterator<Map.Entry<RenderCacheKey, Slot<V>>> it = map.entrySet().iterator();
        while (currentBytes > maxBytes && it.hasNext()) {
            Slot<V> s = it.next().getValue(); // eldest = least recently used
            it.remove();
            currentBytes -= s.bytes;
            evictions.incrementAndGet();
            out.add(s.value);
        }
    }

    private void safeRelease(V v) {
        try {
            v.release();
        } catch (Throwable t) {
            releaseFailures.incrementAndGet();
        }
    }
}
