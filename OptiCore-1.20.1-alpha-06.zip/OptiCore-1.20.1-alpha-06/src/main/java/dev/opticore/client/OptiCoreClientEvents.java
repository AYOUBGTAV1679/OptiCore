package dev.opticore.client;

import dev.opticore.OptiCore;
import dev.opticore.OptiCoreConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = OptiCore.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class OptiCoreClientEvents {
    private OptiCoreClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        while (OptiCoreClient.OPEN_SETTINGS.consumeClick()) {
            mc.setScreen(new OptiCoreSettingsScreen());
        }
    }

    @SubscribeEvent
    public static void onComputeFov(ComputeFovModifierEvent event) {
        if (!OptiCoreConfig.ENABLE_ZOOM.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !OptiCoreClient.ZOOM.isDown()) return;
        float factor = OptiCoreConfig.ZOOM_FACTOR.get().floatValue();
        event.setNewFovModifier(event.getFovModifier() * factor);
    }

    @SubscribeEvent
    public static void onHudRender(RenderGuiOverlayEvent.Post event) {
        // This event fires once per GUI overlay (hotbar, health, chat, ...). Draw only after
        // the hotbar so the counter is rendered once per frame, not once per overlay.
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        if (!OptiCoreConfig.SHOW_FPS.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        String text = "OptiCore | " + mc.getFps() + " FPS";
        event.getGuiGraphics().drawString(mc.font, Component.literal(text), 6, 6, 0xFFFFFF, true);
    }
}
