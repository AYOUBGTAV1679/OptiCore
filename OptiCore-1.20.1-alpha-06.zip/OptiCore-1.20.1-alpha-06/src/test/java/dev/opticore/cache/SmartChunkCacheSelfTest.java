package dev.opticore.cache;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** Dependency-free tests (JUnit cannot be downloaded in the build sandbox). Exit code 1 on failure. */
public final class SmartChunkCacheSelfTest {
    static int passed, failed;

    static final class E implements CacheEntry {
        final long size; final AtomicInteger released = new AtomicInteger(); final boolean throwOnRelease;
        E(long size) { this(size, false); }
        E(long size, boolean t) { this.size = size; this.throwOnRelease = t; }
        public long sizeBytes() { return size; }
        public void release() { released.incrementAndGet(); if (throwOnRelease) throw new IllegalStateException("boom"); }
    }
    static RenderCacheKey k(int x, int z, int s) { return new RenderCacheKey("overworld", x, z, s); }

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("PASS  " + name); }
        else { failed++; System.out.println("FAIL  " + name); }
    }

    public static void main(String[] a) throws Exception {
        hitMiss(); lruOrder(); getRefreshesRecency(); oversizeRejected(); shrinkEvicts();
        invalidateChunk(); resourceReload(); settingsChange(); replaceAccounting();
        releaseThrows(); clearReleasesAll(); concurrency();
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }

    static void hitMiss() {
        var c = new SmartChunkCache<E>(100); var e = new E(10);
        check("get on empty is miss", c.get(k(0,0,0)) == null);
        c.put(k(0,0,0), e);
        check("get after put is hit", c.get(k(0,0,0)) == e);
        var s = c.stats();
        check("stats hits=1 misses=1", s.hits() == 1 && s.misses() == 1);
    }

    static void lruOrder() {
        var c = new SmartChunkCache<E>(30); E a = new E(10), b = new E(10), d = new E(10), f = new E(10);
        c.put(k(0,0,0), a); c.put(k(1,0,0), b); c.put(k(2,0,0), d);
        c.put(k(3,0,0), f); // must evict a (eldest)
        check("eldest evicted & released", c.get(k(0,0,0)) == null && a.released.get() == 1);
        check("others kept", c.get(k(1,0,0)) == b && c.get(k(2,0,0)) == d && c.get(k(3,0,0)) == f);
        check("bytes within bound", c.currentBytes() == 30 && c.currentBytes() <= c.maxBytes());
    }

    static void getRefreshesRecency() {
        var c = new SmartChunkCache<E>(30); E a = new E(10), b = new E(10), d = new E(10), f = new E(10);
        c.put(k(0,0,0), a); c.put(k(1,0,0), b); c.put(k(2,0,0), d);
        c.get(k(0,0,0)); // a becomes most recent, b is now eldest
        c.put(k(3,0,0), f);
        check("recently read entry survives, b evicted", c.get(k(0,0,0)) == a && c.get(k(1,0,0)) == null && b.released.get() == 1);
    }

    static void oversizeRejected() {
        var c = new SmartChunkCache<E>(50); E big = new E(51);
        check("oversize put returns false", !c.put(k(0,0,0), big));
        check("oversize value released once, not stored", big.released.get() == 1 && c.size() == 0 && c.stats().rejected() == 1);
    }

    static void shrinkEvicts() {
        var c = new SmartChunkCache<E>(100);
        for (int i = 0; i < 10; i++) c.put(k(i,0,0), new E(10));
        c.setMaxBytes(35);
        check("shrink evicts down to limit", c.currentBytes() <= 35 && c.size() == 3);
        check("shrink keeps most recent", c.get(k(9,0,0)) != null && c.get(k(0,0,0)) == null);
    }

    static void invalidateChunk() {
        var c = new SmartChunkCache<E>(1000); E a = new E(1), b = new E(1), o = new E(1), n = new E(1);
        c.put(k(5,5,0), a); c.put(k(5,5,1), b); c.put(k(5,6,0), o);
        c.put(new RenderCacheKey("nether", 5, 5, 0), n);
        int removed = c.invalidateChunk("overworld", 5, 5);
        check("invalidateChunk removes exactly that chunk's sections", removed == 2 && c.get(k(5,5,0)) == null && c.get(k(5,5,1)) == null);
        check("neighbouring chunk and other dimension untouched", c.get(k(5,6,0)) == o && c.get(new RenderCacheKey("nether",5,5,0)) == n);
        check("invalidated entries released, bytes consistent", a.released.get() == 1 && b.released.get() == 1 && c.currentBytes() == 2);
    }

    static void resourceReload() {
        var c = new SmartChunkCache<E>(1000); E a = new E(5);
        c.put(k(0,0,0), a); c.onResourcesReloaded();
        check("entry stale after resource reload", c.get(k(0,0,0)) == null && a.released.get() == 1 && c.currentBytes() == 0);
        E b = new E(5); c.put(k(0,0,0), b);
        check("entries stored after reload are valid", c.get(k(0,0,0)) == b);
    }

    static void settingsChange() {
        var c = new SmartChunkCache<E>(1000); E a = new E(5), b = new E(5);
        c.put(k(0,0,0), a); c.put(k(1,0,0), b); c.onRenderSettingsChanged();
        check("purgeStale frees all stale entries", c.purgeStale() == 2 && a.released.get() == 1 && b.released.get() == 1 && c.size() == 0);
    }

    static void replaceAccounting() {
        var c = new SmartChunkCache<E>(100); E a = new E(40), b = new E(10);
        c.put(k(0,0,0), a); c.put(k(0,0,0), b);
        check("replace releases old, bytes accounting correct", a.released.get() == 1 && b.released.get() == 0 && c.currentBytes() == 10 && c.size() == 1);
        c.put(k(0,0,0), b); // same instance re-put must not release it
        check("re-putting same instance does not release it", b.released.get() == 0 && c.currentBytes() == 10);
    }

    static void releaseThrows() {
        var c = new SmartChunkCache<E>(10); E bad = new E(10, true), ok = new E(10);
        c.put(k(0,0,0), bad);
        c.put(k(1,0,0), ok); // evicts bad; its release throws
        check("throwing release is contained and counted", c.get(k(1,0,0)) == ok && c.stats().releaseFailures() == 1 && c.currentBytes() == 10);
    }

    static void clearReleasesAll() {
        var c = new SmartChunkCache<E>(1000); List<E> l = new ArrayList<>();
        for (int i = 0; i < 20; i++) { E e = new E(3); l.add(e); c.put(k(i,0,0), e); }
        c.clear(); c.clear();
        check("clear releases each entry exactly once, idempotent", l.stream().allMatch(e -> e.released.get() == 1) && c.size() == 0 && c.currentBytes() == 0);
    }

    static void concurrency() throws Exception {
        final long MAX = 2_000;
        var c = new SmartChunkCache<E>(MAX);
        List<E> all = Collections.synchronizedList(new ArrayList<>());
        ExecutorService ex = Executors.newFixedThreadPool(8);
        AtomicLong boundViolations = new AtomicLong();
        List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < 8; t++) {
            final int seed = t;
            fs.add(ex.submit(() -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (int i = 0; i < 60_000; i++) {
                    int op = r.nextInt(100); var key = k(r.nextInt(40), r.nextInt(40), r.nextInt(4));
                    if (op < 45) { E e = new E(1 + r.nextInt(120)); all.add(e); c.put(key, e); }
                    else if (op < 85) c.get(key);
                    else if (op < 90) c.invalidateChunk("overworld", r.nextInt(40), r.nextInt(40));
                    else if (op < 93) c.onRenderSettingsChanged();
                    else if (op < 95) c.onResourcesReloaded();
                    else if (op < 97) c.purgeStale();
                    else if (op < 99) c.setMaxBytes(MAX - r.nextInt(500)); // shrink/grow concurrently
                    if (c.currentBytes() > MAX) boundViolations.incrementAndGet();
                }
            }));
        }
        for (var f : fs) f.get(120, TimeUnit.SECONDS);
        ex.shutdown();
        check("concurrent: bound never exceeded", boundViolations.get() == 0);
        long live = c.currentBytes(); int size = c.size();
        c.clear();
        boolean exactlyOnce = true; int bad = 0;
        for (E e : all) if (e.released.get() != 1) { exactlyOnce = false; bad++; }
        check("concurrent: every created entry released exactly once (bad=" + bad + ", total=" + all.size() + ")", exactlyOnce);
        check("concurrent: empty after clear", c.size() == 0 && c.currentBytes() == 0);
        System.out.println("      (stress: " + all.size() + " entries created, final live=" + size + " entries/" + live + " bytes, stats=" + c.stats() + ")");
    }
}
