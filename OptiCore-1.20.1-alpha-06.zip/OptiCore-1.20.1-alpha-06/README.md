# OptiCore

Independent Minecraft Forge 1.20.1 visual/performance mod project. No Embeddium or Oculus dependency.

## Current implementation (Alpha 06)
- Settings screen (O), hold C to zoom, optional FPS HUD counter.
- Client configuration for zoom and FPS.
- Compatibility presence scanner in settings: reports whether selected mod IDs are loaded.

## Scanner limitation
Presence detection does **not** certify that a mod works correctly with OptiCore. Mod IDs can vary by release and require confirmation from an actual Forge log. This is a diagnostic starting point, not a compatibility guarantee.

## Build
Requires JDK 17 and ForgeGradle. Run `gradle build`; output should be in `build/libs/`.
This source package has not been compiled against Forge or launched in Minecraft. Only `dev.opticore.cache` is compiled and tested (`scripts/run-cache-tests.sh`, plain JDK 17). See CHANGELOG.md.

## Roadmap — not implemented
Independent chunk renderer; wiring the (implemented, tested, currently unused) Smart Chunk Cache into rendering; shader pipeline independent of Oculus; connected textures; dynamic lights; emissive textures; custom entity models; random entities; regression tests against the user's mod list.

The future chunk cache must store only disposable render data, never world simulation state, entity AI, or gameplay state.
