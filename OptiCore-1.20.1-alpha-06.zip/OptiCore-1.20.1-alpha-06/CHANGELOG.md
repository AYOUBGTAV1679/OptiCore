# OptiCore changelog

## Alpha 06 (0.6.0-alpha)

### Alpha 05 audit (static inspection only; the project could not be built here)
Alpha 05 is 14 files / ~13 KB. What actually exists: settings screen (O), hold-to-zoom (C, via
`ComputeFovModifierEvent`), FPS HUD text, presence-only compatibility scanner, client config.
Nothing from roadmap items 3-6 existed. Version strings said `0.4.0-alpha` / "Alpha 0.4" in an Alpha 05 archive.

Defects found by reading the code:
1. **FPS HUD drew once per GUI overlay** (`RenderGuiOverlayEvent.Post` fires for every overlay), i.e. many times per frame. -> FIXED (draw only after the hotbar overlay). *Compile + in-game behavior unverified.*
2. `mods.toml` had no `forge`/`minecraft` dependency blocks. -> ADDED. *Unverified (not loaded in Forge).*
3. Version mismatch across build.gradle / mods.toml / README. -> unified to 0.6.0-alpha.
4. No Gradle wrapper in the archive; `gradle build` depends on the user's installed Gradle (ForgeGradle 6.0 needs Gradle 8.x). NOT fixed.
5. Zoom caveat (not fixed): zoom multiplies the FOV *modifier*, which vanilla scales by the "FOV Effects" option; at 0% zoom will have no effect. `ViewportEvent.ComputeFov` is the likely fix; needs in-game testing.
6. Compatibility screen: no scrolling (rows beyond screen height are silently cut) and the `note` column is never shown. NOT fixed.
7. Scanner mod IDs are guesses and unconfirmed against a real log.

### Implemented and tested: Smart Chunk Cache core (`dev.opticore.cache`)
- Bounded LRU by **bytes**, runtime-adjustable limit (`setMaxBytes`, shrinking evicts immediately).
- Thread-safe (single lock; release callbacks run outside the lock; throwing release is contained).
- Invalidation: per chunk, per dimension, resource reload and render-settings change (generation stamps, lazy + `purgeStale()`), `clear()`.
- Stores only objects implementing `CacheEntry` (disposable render data); no Minecraft types, no world/entity/gameplay references.
- 24 checks in `SmartChunkCacheSelfTest`, including an 8-thread stress run (216k entries, bound never exceeded, every entry released exactly once). Log: `logs/cache-tests.log`. Run: `scripts/run-cache-tests.sh` (JDK 17).

**This does NOT make the game faster yet.** Nothing calls the cache: it is not hooked into any renderer, there is no config option for the limit, and no chunk/resource/settings event is wired to the invalidation methods. Those need the renderer work below.

### Not implemented (still unfinished)
Independent rendering optimizer, shader system, Dynamic Lights, Connected Textures, Custom Entity Models, Random Entities, Emissive Textures, Custom Sky/Colors, Better Grass/Snow, Smart Animations, Advanced Video Settings, cache wiring + config, mod-list regression testing (no mod list was provided in this session).

### Build status
- `gradle build`: **NOT RUN** - sandbox blocks maven.minecraftforge.net, services.gradle.org, Maven Central, Mojang (`logs/build-status.log`).
- Forge-dependent code (everything outside `dev.opticore.cache`) has **never been compiled** by me; Alpha 05's compile status remains unknown.
- **No JAR was produced.**
